# Organized
Exercices to organize files and folders with line command
